<!DOCTYPE>
<html>
<head>
	<title>ApChat</title>
	<script src="apstyle/js/apstyle.js"></script>
	<link rel="stylesheet" type="text/css" href="apstyle/css/main.css">
</head>
<body>

<script>
$(document).ready(function(){
	alert("jQuery is loded properly..");
});
</script>
</body>
</html>