k=input()
print (k)