import java.util.*;
public class problem1{

    public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
    int a=sc.nextInt()
        System.out.println("Hello World");
    }

}