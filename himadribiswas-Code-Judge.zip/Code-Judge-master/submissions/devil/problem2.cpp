#include<stdio.h>
int main()
{
	int a,b;
	scanf("%d",&a);
	if(a%7==0 || a%10==7)
	printf("Buzz");
	else
	printf("Not  buzz ");
	
	
}