#include<iostream.h>
using namespace std;
main()
{
	int n;
	cin>>n;
	if(((n/10)==7) || ((n%10)==7))
	cout<<"Buzz";
	else
	cout<<"Not Buzz";
	return 0;
	
	
}