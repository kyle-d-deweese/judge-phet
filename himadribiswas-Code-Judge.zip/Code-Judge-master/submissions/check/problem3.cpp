#include<stdio.h>
main()
{
int n;
scanf("%d",&n);
printf("%d",n);
}