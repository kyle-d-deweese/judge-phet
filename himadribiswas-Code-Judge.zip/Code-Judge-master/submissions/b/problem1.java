import java.util.*;

public class problem1
{
   public static void main(String[]args)
   {
      Scanner input = new Scanner(System.in);

      int i = input.nextInt();

      System.out.println( i);        
   }
}