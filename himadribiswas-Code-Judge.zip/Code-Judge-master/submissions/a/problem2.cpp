#include<stdio.h>
 main()
{
while(1)
    printf("Hello");
}