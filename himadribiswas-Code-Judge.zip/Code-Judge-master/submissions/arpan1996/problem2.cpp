#include <iostream>
using namespace std;
int main()
{

while(true)
cout<<"hi";
}