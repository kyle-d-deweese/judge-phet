import java.util.Scanner;

public class problem1 {
	public static void main(String args[]) {
		int MM, DD, YYYYCdays;
		Scanner sc = new Scanner(System.in);
		MM = sc.nextInt();
DD = sc.nextInt();
YYYY = sc.nextInt();
for(int i=1;i<MM;i++)
{
Cdays=Cdays+31;

	}
Cdays=Cdays+DD;
System.out.println("CORRESPONDING DAY OF THE YEAR IS :"+Cdays);
}
