#include <stdio.h>

    int main()
    {
      printf("Hello PHP-C world");
      return 0;
    }