# DMOJ Documentation

Documentation for the [DMOJ judge](https://github.com/DMOJ/judge-server) system.

Access at <https://docs.dmoj.ca>.
