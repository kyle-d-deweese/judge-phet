#ifndef idC1005C52_79B1_4EDB_805524743ECA9AB5
#define idC1005C52_79B1_4EDB_805524743ECA9AB5

int setbits(unsigned long long);

#endif
