# DMOJ: Modern Online Judge

This documentation aims to guide you through installing your own DMOJ instance.

Feel free to reach out to us on [Discord](https://dmoj.ca/about/discord/) if you have any
questions.
